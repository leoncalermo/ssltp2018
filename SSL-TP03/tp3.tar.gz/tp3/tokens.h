#ifndef INCLUDE_TOKENS
#define INCLUDE_TOKENS

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
enum tokens{IDENTIFICADOR=1, NUMERO, ASIGN};


#endif