#ifndef SYMBOL_H
#define SYMBOL_H

int definirIdentificador(char* id);
int noExiste(char* x);
void agregar(char* x);
int buscarIdentificador(char* id);
int validarIdentificador(char* id);

#endif
